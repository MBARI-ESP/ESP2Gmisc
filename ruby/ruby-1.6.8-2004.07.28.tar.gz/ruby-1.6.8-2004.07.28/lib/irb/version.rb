#
#   irb/version.rb - irb version definition file
#   	$Release Version: 0.7.4$
#   	$Revision: 1.1.2.2 $
#   	$Date: 2001/05/16 20:44:26 $
#   	by Keiju ISHITSUKA(keiju@ishitsuka.com)
#
# --
#
#   
#

module IRB
  @RELEASE_VERSION = "0.7.4"
  @LAST_UPDATE_DATE = "01/05/08"
end
