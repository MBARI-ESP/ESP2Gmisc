# $Id: final.rb,v 1.3 2000/07/15 13:37:03 matz Exp $
# Copyright (C) 1998 Yukihiro Matsumoto. All rights reserved. 

# final.rb is integrated into ObjectSpace; no longer needed.
