#!/usr/bin/ruby

require "gtk"

accel = Gtk::AccelGroup.new

# Main Menu
itemfact = Gtk::ItemFactory.new(Gtk::ItemFactory::TYPE_MENU_BAR,
                                "<main>", accel)
itemfact.create_item("/Test", nil,
Gtk::ItemFactory::BRANCH)
itemfact.create_item("/Test/1", nil,
Gtk::ItemFactory::ITEM){|w| p w}

box = Gtk::VBox.new
box.pack_start(itemfact.get_widget("<main>").show,false,true,0)

# Main Window
window = Gtk::Window.new(Gtk::WINDOW_TOPLEVEL)
accel.attach(window)
window.add(box)
window.show_all


# main loop
Gtk.main
