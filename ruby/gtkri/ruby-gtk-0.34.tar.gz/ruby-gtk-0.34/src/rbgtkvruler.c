/* -*- c-file-style: "ruby" -*- */
/************************************************

  rbgtkvruler.c -

  $Author: klamath $
  $Date: 2001/10/04 02:13:45 $

  Copyright (C) 1998-2000 Yukihiro Matsumoto,
                          Daisuke Kanda,
                          Hiroshi Igarashi
************************************************/

#include "global.h"

static VALUE
vruler_initialize(self)
    VALUE self;
{
    set_widget(self, gtk_vruler_new());
    return Qnil;
}

void Init_gtk_vruler()
{
    gVRuler = rb_define_class_under(mGtk, "VRuler", gRuler);

    rb_define_method(gVRuler, "initialize", vruler_initialize, 0);
}
