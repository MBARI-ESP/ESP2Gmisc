/* -*- c-file-style: "ruby" -*- */
/************************************************

  rbgtkseparator.c -

  $Author: klamath $
  $Date: 2001/10/04 02:13:43 $

  Copyright (C) 1998-2000 Yukihiro Matsumoto,
                          Daisuke Kanda,
                          Hiroshi Igarashi
************************************************/

#include "global.h"

void Init_gtk_separator()
{
    gSeparator = rb_define_class_under(mGtk, "Separator", gWidget);

    /* child init */
    Init_gtk_hseparator();
    Init_gtk_vseparator();
}
