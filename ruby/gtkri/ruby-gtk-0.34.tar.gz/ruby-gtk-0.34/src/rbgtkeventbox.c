/* -*- c-file-style: "ruby" -*- */
/************************************************

  rbgtkeventbox.c -

  $Author: klamath $
  $Date: 2001/10/04 02:13:41 $

  Copyright (C) 1998-2000 Yukihiro Matsumoto,
                          Daisuke Kanda,
                          Hiroshi Igarashi
************************************************/

#include "global.h"

static VALUE
eventbox_initialize(self)
    VALUE self;
{
    set_widget(self, gtk_event_box_new());
    return Qnil;
}

void Init_gtk_eventbox()
{
    gEventBox = rb_define_class_under(mGtk, "EventBox", gBin);

    rb_define_method(gEventBox, "initialize", eventbox_initialize, 0);
}
