/* -*- c-file-style: "ruby" -*- */
/************************************************

  rbgtkscrollbar.c -

  $Author: klamath $
  $Date: 2001/10/04 02:13:43 $

  Copyright (C) 1998-2000 Yukihiro Matsumoto,
                          Daisuke Kanda,
                          Hiroshi Igarashi
************************************************/

#include "global.h"

void Init_gtk_scrollbar()
{
  gScrollbar = rb_define_class_under(mGtk, "Scrollbar", gRange);

  /* child init */
  Init_gtk_hscrollbar();
  Init_gtk_vscrollbar();
}
