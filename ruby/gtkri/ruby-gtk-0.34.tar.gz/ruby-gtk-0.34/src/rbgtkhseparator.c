/* -*- c-file-style: "ruby" -*- */
/************************************************

  rbgtkhseparator.c -

  $Author: klamath $
  $Date: 2001/10/04 02:13:41 $

  Copyright (C) 1998-2000 Yukihiro Matsumoto,
                          Daisuke Kanda,
                          Hiroshi Igarashi
************************************************/

#include "global.h"

static VALUE
hsep_initialize(self)
    VALUE self;
{
    set_widget(self, gtk_hseparator_new());
    return Qnil;
}

void Init_gtk_hseparator()
{
    gHSeparator = rb_define_class_under(mGtk, "HSeparator", gSeparator);

    rb_define_method(gHSeparator, "initialize", hsep_initialize, 0);
}
